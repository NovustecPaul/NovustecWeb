<div id="ft" style="">
	
    <div class="inner_wrap" style="padding-bottom:30px;position:relative">
    	<div id="s_top" style="position:absolute;top:-70px; right:0px;">
        <a style="color:#fff;background:#b0bcc8; padding:3px 10px;"href="#" title=Top>Top</a>
        </div>
        <h3><img src="inc/img/copyright_logo.png" alt="Novustec logo" /></h3>
        <p class="copyright">Copyright ©2015 Novustec</p>
        <p class="corp_info">사업자등록번호: 129-86-86827 | 대표이사: 한영준 | 주소: 경기도 성남시 중원구 상대원동 한라시그마밸리 403호</p>
        
        <p style="background:url('inc/img/ft.png') no-repeat 0px 2px; height:20px; margin-top:3px; padding:5px 0px 0px 0px;">
        	<span style="padding-left:25px;">031-745-3690</span>
            <span style="padding-left:43px;">010-4204-3225</span>
            <span style="padding-left:43px;">youngjoon.han@novustec.co.kr</span>
        </p>
        
    </div>
</div>