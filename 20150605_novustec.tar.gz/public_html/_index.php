<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>[ȣ�������̾�] ������ �������� ��ȣ����</title>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">

<style type="text/css">
<!--
body {
        background-image: url(http://www.hosting.kr/images/error/bg.jpg);
        font-family: "����";
        font-size: 12px;
        color: #666666;
}
td {font-family: "����";
        font-size: 12px;
        color: #666666;
}
-->
</style>
<link href="http://www.hosting.kr/Common/css/defaultpage.css" rel="stylesheet" type="text/css">
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table width="100%" border="0" cellpadding="0" cellspacing="10">
  <tr>
    <td width="50%" height="60" valign="top"><a href="http://www.hosting.kr"><img src="http://www.hosting.kr/images/error/logo.gif" border="0"></a></td>
    <td width="50%" align="right" valign="top"><img src="http://www.hosting.kr/images/error/slogun.gif"></td>
  </tr>
</table>
<table width="100%" border="0" cellpadding="0" cellspacing="10">
  <tr>
    <td width="50%"></td>
    <td width="663"><table width="663" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="663" height="108" background="http://www.hosting.kr/images/error/img_1.gif"><img src="http://www.hosting.kr/images/registcomplet_img.jpg"></td>
      </tr>
      <tr>
        <td><table width="663" border="0" cellspacing="0" cellpadding="0">
          <tr>
                    <td height="15"></td>
                  </tr>
                  <tr>
            <td>
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="2" bgcolor="FF9C01"></td>
                  <td bgcolor="FF9C01"></td>
                  <td bgcolor="FF9C01"></td>
                  <td bgcolor="FF9C01"></td>
                  <td bgcolor="FF9C01"></td>
                  <td bgcolor="FF9C01"></td>
                  <td bgcolor="FF9C01"></td>
                  <td bgcolor="FF9C01"></td>
                  <td bgcolor="FF9C01"></td>
                </tr>
                <tr>
                  <td width="1" bgcolor="CCCCCC"></td>
                  <td width="114" bgcolor="FFFFFF">
                    <table width="100%" border="0" cellspacing="0" cellpadding="1">
                      <tr>
                        <td height="29">
                          <table width="100%" border="0" cellspacing="0" cellpadding="5">
                            <tr>
                              <td height="29" align="center" bgcolor="F4F4F4"><strong>������</strong></td>
                            </tr>
                          </table>
                        </td>
                      </tr>
                    </table>
                  </td>
                  <td width="1" bgcolor="CCCCCC"></td>
                  <td colspan="5" bgcolor="FFFFFF" style="padding:0 0 0 10"><? echo $_SERVER['HTTP_HOST'] ?></td>
                  <td width="1" bgcolor="CCCCCC"></td>
                </tr>
                <tr>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC" height="1"></td>
                  <td width="1" bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC" height="1"></td>
                  <td bgcolor="CCCCCC"></td>
                </tr>
                <tr>
                  <td bgcolor="CCCCCC"></td>
                  <td width="114" bgcolor="FFFFFF">
                    <table width="100%" border="0" cellspacing="0" cellpadding="1">
                      <tr>
                        <td height="29">
                          <table width="100%" border="0" cellspacing="0" cellpadding="5">
                            <tr>
                              <td height="29" align="center" bgcolor="F4F4F4"><strong>FTP ���� �ּ�</strong></td>
                            </tr>
                          </table>
                        </td>
                      </tr>
                    </table>
                  </td>
                  <td width="1" bgcolor="CCCCCC"></td>
                  <td colspan="5" bgcolor="FFFFFF" style="padding:0 0 0 10">
                                  <? echo $_SERVER['HTTP_HOST']."(".$_SERVER['SERVER_ADDR'].")" ?>
                                  </td>
                  <td bgcolor="CCCCCC"></td>
                </tr>
                <tr>
                  <td height="1" bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                </tr>
                <tr>
                  <td height="1" bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                </tr>

                <tr>
                  <td height="1" bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                  <td bgcolor="CCCCCC"></td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td height="30">�� �� ���� ������ ��ġ �Ϸ� ������ �����Ͻñ� �ٶ��ϴ�.<br></td>
          </tr>
          <tr>
            <td><img src="http://www.hosting.kr/images/img_04.gif" border="0" usemap="#Map2" /></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="20"></td>
      </tr>
      <tr>
        <td><img src="http://www.hosting.kr/images/common/4reason.gif" border="0" usemap="#Map3" /></td>
      </tr>

    </table></td>
    <td width="50%"></td>
  </tr>
</table>



<map name="Map"><area shape="rect" coords="480,428,574,457" href="#"></map>
<map name="Map2"><area shape="rect" coords="45,93,167,122" href="http://www.hosting.kr/servlet/html?tegea=ged&pgm_id=HOSTING050000"><area shape="rect" coords="247,50,471,74" href="mailto:help@hosting.co.kr"></map>

<map name="Map3">
<area shape="rect" coords="31,55,225,82" href="http://www.hosting.kr/servlet/html?pgm_id=HOSTING000002" target="_blank"><area shape="rect" coords="275,47,434,76" href="http://www.hosting.kr/servlet/html?pgm_id=HOSTING000006" target="_blank">
</map></body>
</html>
