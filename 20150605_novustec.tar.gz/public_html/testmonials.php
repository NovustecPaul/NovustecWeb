<?
include_once "_hd.php";
?>



<div id="testmonials" class="wrap">

    
    <?
	include_once "_gnb.php";
	?>
    
    
    <div id="bd">
    	<div id="sub_title_wrap">
        	<div id="blue_bar"></div>
            
            <div id="sub_title">
            	<h3><img src="inc/img/sub_title_testmonials.png" alt="Testmonials" /></h3>
                <p>What Our Customers Say About Novustec</p>
            </div>
        </div><!--#sub_title_wrap-->
        
        
        
        <div class="inner_wrap">
        	<div class="left"></div>
            <div class="right">
            
            
            
            	<div class="section" id="partners">
                	<h4>Our Partners</h4>
                    <dl>
                    	<dd><img src="inc/img/testmonials_thumb_0.png" alt="Novustec partner" /></dd>
                    	<dt>엘카페</dt>
                    </dl>
                    <dl>
                    	<dd><img src="inc/img/testmonials_thumb_1.png" alt="Novustec partner" /></dd>
                    	<dt>커피빌라</dt>
                    </dl>
                    <dl>
                    	<dd><img src="inc/img/testmonials_thumb_2.png" alt="Novustec partner" /></dd>
                    	<dt>나무사이로</dt>
                    </dl>
                    
                    <dl>
                    	<dd><img src="inc/img/testmonials_thumb_3.png" alt="Novustec partner" /></dd>
                    	<dt>서동진의 커피랩</dt>
                    </dl>
                    
                    
                    
                    <dl>
                    	<dd><img src="inc/img/testmonials_thumb_4.png" alt="Novustec partner" /></dd>
                    	<dt>커피304</dt>
                    </dl>
                    <dl>
                    	<dd><img src="inc/img/testmonials_thumb_5.png" alt="Novustec partner" /></dd>
                    	<dt>커피노트</dt>
                    </dl>
                    <dl>
                    	<dd><img src="inc/img/testmonials_thumb_6.png" alt="Novustec partner" /></dd>
                    	<dt>커피보리</dt>
                    </dl>
                    
                    <dl>
                    	<dd><img src="inc/img/testmonials_thumb_7.png" alt="Novustec partner" /></dd>
                    	<dt>커피볶는자유</dt>
                    </dl>
                    
                    <dl class="last">
                    	<dd><img src="inc/img/testmonials_thumb_8.png" alt="Novustec partner" /></dd>
                    	<dt></dt>
                    </dl>
                    
                    <div class="cb"></div>                                                                                           
                </div><!--.section-->
                    


            	<div class="section" id="news">
                	<h4>News & Coverage</h4>
                    
                    <a href="http://www.podbbang.com/ch/6274" target="_blank">
	                    <dl>
                        	<dt>마담 K의 커피하우스</dt>
                            <dd class="desc"> - 11회 '로스터를 보았다' with 한영준님</dd>
                            <dd class="arrow_icon"></dd>
                        </dl>
                    </a>
                    
                    <a href="http://bwissue.com/?mid=news&page=9&document_srl=85262" target="_blank">
	                    <dl>
                        	<dt>커피 뉴스 &lt;2014 카페쇼&gt; 中</dt>
                            <dd class="desc"> -  "고효율의 높은 대류열을 발생시키기 때문에 보다 효과적인 로스팅이 가능하다. "</dd>
                            <dd class="arrow_icon"></dd>
                        </dl>
                    </a>                    
                </div><!--.section-->                     
            </div>                       
        </div><!--.inner_wrap-->
    </div><!--#bd-->
    
    
    
    
    
<?
include_once "_ft.php";
?>



</div><!--.wrap-->
<script type="text/javascript" src="inc/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="inc/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="inc/js/jquery.hks_layer_popup.js"></script>
<script type="text/javascript" src="inc/js/jquery.hks_form.js"></script>
<script type="text/javascript" src="inc/js/common.js"></script>
<script type="text/javascript">
$(function(){
	setNav('m3');
});
</script>


</body>
</html>
