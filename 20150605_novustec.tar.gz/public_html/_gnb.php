<div id="hd">
    <div class="top">
        <h1><a href="index.php"><img src="inc/img/logo.png" alt="Novustec logo" /></a></h1>
        
        <a id="btn_eng" href="#none" onClick="alert('under construction')">English</a>
    </div>
    <div id="gnb">
        <div id="main_nav">
            <div class="inner_wrap">
                <a href="index.php" id="m1" class="gnb">HOME</a>
                <a href="about.php" id="m2" class="gnb">ABOUT US</a>
                <a href="testmonials.php" id="m3" class="gnb">TESTIMONIALS</a>
                <a href="products_trinitas2.php" id="m4" class="gnb">PRODUCTS</a>
                <a href="#none" id="btn_pop_contact" class="right">CONTACT US</a>
                <div class="cb"></div>
            </div>
        </div><!--#main_nav-->
            
        
        <div id="sub_nav">
            <div class="inner_wrap">  
                <a href="products_trinitas2.php">TRINITAS T2</a>         	
            </div>
        </div>
    </div><!--#gnb-->
</div><!--#hd-->