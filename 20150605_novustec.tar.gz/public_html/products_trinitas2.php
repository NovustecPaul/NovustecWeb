<?
include_once "_hd.php";
?>

<style type="text/css">
#features dd,#features dt{display:none}
</style>

<div id="p_trinitas2" class="wrap">

    
    <?
	include_once "_gnb.php";
	?>
    
    
    <div id="bd">
    	<div id="sub_title_wrap">
        	<div id="blue_bar"></div>
            
            <div id="sub_title">
            	<h3><img src="inc/img/sub_title_products_trinitas2.png" alt="Products > Trinitas T2" /></h3>
                <p>TRINITAS T2 커피 로스터는 2006년부터 계속되어 온 고집스런 장인정신과 기술력을 바탕으로 개발되었으며,<br />그 동안 Caffeol Test Lab과 본사 R&D센터를 통한 지속적인 Cupping과 데이터의 축적을 통해 완성되었습니다.</p>
            </div>
        </div><!--#sub_title_wrap-->
        
        
        
        <div class="inner_wrap">
        	<div class="left"></div>
            <div class="right">
            	<div class="section" id="features">
                	<h4>Technical Features</h4>
                    <dl>
                    	<dt>로스팅 시간</dt>
                        <dd class="value">7분</dd>
                        <dd class="icon"><img src="inc/img/products_trinitas2_icon_0.png" alt="" /></dd>
                    </dl>
                    <dl>
                    	<dt>로스팅 용량</dt>
                        <dd class="value">2kg/batch</dd>
                        <dd class="icon"><img src="inc/img/products_trinitas2_icon_1.png" alt="" /></dd>
                    </dl>
                    <dl>
                    	<dt>열원 타입</dt>
                        <dd class="value">LPG / LNG</dd>
                        <dd class="icon"><img src="inc/img/products_trinitas2_icon_2.png" alt="" /></dd>
                    </dl>
                    <dl>
                    	<dt>시간당 생산량</dt>
                        <dd class="value">10kg</dd>
                        <dd class="icon"><img src="inc/img/products_trinitas2_icon_3.png" alt="" /></dd>
                    </dl>  
                    
                    <div class="cb"></div>                                                          
                </div><!--.section-->
                
                <div class="section p_info" id="p_info_0">
                	<h5>안정된 프로파일</h5>
                    <p class="desc">커피 로스팅에는 많은 환경적인 요소들과 로스터기의 상태가 복합적으로 작용하여 맛을 창출합니다. 하지만, 로스팅의 순간 마다 커피의 맛이 달라져서 일정한 맛을 내기 힘들다면 그것또한 문제입니다. Trinitas T2는 안정된 열원의 공급과 유지를 보장하는 설계로 사용자가 구축한 프로파일을 매 순간 일정하게 재현합니다. 투입온도, 투입열량, 배출타이밍 이 세가지가 결정되면이미 사용자의 프로파일과 똑같은 상태로 성실하게 재현합니다.</p>
                    <img class="lazy" data-original="inc/img/products_trinitas2_img_0.png" alt="Novustec Trinitas T2" /> 
                </div><!--.section-->
                
                <div class="section p_info" id="p_info_1">
                	<h5>높은 로스팅 성공률</h5>
                    <p class="desc">커피 로스터기의 역할은 커피 콩의 본연의 맛과 향을 성공적으로 구현하는 것입니다. 이것이 바로 Trinitas T2의 사용자를 위한 저희의 노력입니다. 사용자께서는 좋은 생두를 선택하고 그 결과물을 맛보는 것에 집중하십시오. 성공적인 로스팅 타겟에안착하기 위한 노력은 저희가 하겠습니다.</p>
                    <img class="lazy" data-original="inc/img/products_trinitas2_img_1.png" alt="Novustec Trinitas T2" /> 
                </div><!--.section-->
                
                <div class="section p_info" id="p_info_2">
                	<h5>심플한 사용방법</h5>
                    <p class="desc">로스팅은 많은 요소들의 영향을 받습니다. 그렇기 때문에 로스팅을 할 때 온도, 시간, 통풍 등 많은 부분에 신경이 쓰이는 것이 사실입니다. 하지만, Trinitas T2의 사용자들에게는 로스팅 과정이 쉬워졌습니다. 투입한 생두의 양과 종류에 따른 투입온도, 그리고 초기투입열량이 결정되면 배출때까지 열량과 댐퍼의 조절 없이 진행이 가능합니다.
                    <br>로스팅 과정의 복잡성으로 어려워하지 마십시오.</p>
                    <img src="inc/img/products_trinitas2_img_2.png" alt="Novustec Trinitas T2" /> 
                </div><!--.section-->  
                
                <div class="section p_info" id="p_info_3">
                	<h5>높은 생산량</h5>
                    <p class="desc">신선한 커피의 상태를 위해 매일 로스팅을 하신다면 커피의 생산량은 매우 중요한 요소입니다. Trinitas T2에는 드럼과 냉각교반의 구동을 위한 2개의 모터, 배기와 냉각을 위한 2개의 송풍모터, 총 4개의독립모터가 연속배치를 가능하게 합니다. 이로써 시간당 최대 10kg의 원두를 생산할 수 있습니다.</p>
                    <img class="lazy" data-original="inc/img/products_trinitas2_img_3.png" alt="Novustec Trinitas T2" /> 
                </div><!--.section-->  
                
                <div class="section p_info" id="p_info_4">
                	<h5>편리한 유지보수</h5>
                    <p class="desc">Trinitas T2는 로스팅을 향한 최적화된 구조를 지향합니다. 군더더기 없는 직관적인 구조로 체프 배출과 내부에 발생하는 슬러지의 청소가 간편합니다. <br />이로써 갑작스러운 고장의 요소도 줄었습니다.</p>
                    <img class="lazy" data-original="inc/img/products_trinitas2_img_4.png" alt="Novustec Trinitas T2" /> 
                </div><!--.section-->                                                                
                
            	<div class="section" id="spec">
                	<h4>Trinitas T2 Specification</h4>
                    <dl>
                    	<dt>Dimension</dt>
                        <dd class="value">W : 350 (mm), H : 1000 (mm), D : 350 (mm)</dd>
                    </dl>   
                    <dl>
                    	<dt>Weight</dt>
                        <dd class="value">00 (kg)</dd>
                    </dl>   
                    <dl>
                    	<dt>Electrical Supply</dt>
                        <dd class="value">220V / 60Hz</dd>
                    </dl>   
                    <dl>
                    	<dt>Gas Consumption</dt>
                        <dd class="value">10KW / 8,600kCal/hour</dd>
                    </dl>   
                    <dl>
                    	<dt>Gas</dt>
                        <dd class="value">LNG / LPG (propane)</dd>
                    </dl>                                                                                                         
                </div><!--.section-->                                                              
            </div>
            
        </div><!--.inner_wrap-->
    </div><!--#bd-->
    
    
    
<?
include_once "_ft.php";
?>

</div><!--.wrap-->

<script type="text/javascript" src="inc/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="inc/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="inc/js/jquery.hks_layer_popup.js"></script>
<script type="text/javascript" src="inc/js/jquery.hks_form.js"></script>
<script type="text/javascript" src="inc/js/jquery.lazyload.js"></script>
<script type="text/javascript" src="inc/js/common.js"></script>
<script type="text/javascript">
$(function(){
	
	$('#features dd,#features dt').fadeIn(3000);
	
	$("div.section img").lazyload({
		effect : "fadeIn",
		effectspeed: 2000
	});
	
	setNav('m4');
});

</script>

</body>
</html>
